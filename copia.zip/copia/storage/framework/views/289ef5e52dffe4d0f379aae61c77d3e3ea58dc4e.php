

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <nav class="h-16 flex justify-end py-4 px-16">
     

        <a href="<?php echo e(route('products.create')); ?>" class="text-white rounded px-4 pt-1 h-10 bg-yellow-500 font-semibold mx-2 hover:bg-yellow-600">Preguntar y Respuesta</a>
    </nav>
    
    <div align="center"><img src="R.png"></div>
    
    <h1 class="text-5xl text-center pt-24">Bienvenido a la pagina Preguntados</h1><br><br>


        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                
                <table class="table-fixed w-full">
                    <thead>
                        <tr class="bg-red-500 text-white">
                  
        
<th class="w-1/16 py-4 ...">Nombre</th>
<th class="w-1/16 py-4 ...">Edad</th>
<th class="w-1/16 py-4 ...">Situacion </th>
<th class="w-1/16 py-4 ...">Descripcion</th>
<th class="w-1/16 py-4 ...">Correo</th>
<th class="w-1/16 py-4 ...">Usuario o invitado</th>
                  
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="py-3 px-6"><div> <?php echo e($products->titulo); ?></div></td>
                            <td class="p-3 txt-center"> <?php echo e($products->autor); ?>  </td>
                            <td class="p-3 text-center"><?php echo e($products->editorial); ?></td>
                            <td class="p-3 text-center"><?php echo e($products->lpublicacion); ?></td>
                            <td class="p-3 text-center"><?php echo e($products->apublicacion); ?></td>
                            <td class="p-3 text-center"><?php echo e($products->categoria); ?></td>
                   
                            <td class="p-3 flex justify-center">
                                <form href="#">
                               
                                    <form action="<?php echo e(route('index.destroy',$products->titulo)); ?>" method="POST" class="mx-auto">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('delete'); ?>  
                  <button class="bg-red-500 text-white px-3 py-1 rounded-sm">
                  <i class="fas fa-trash"></i></button>
                </form>
             

                                <form>
                                <a href="" class="bg-green-500 text-white px-3 py-1 rounded-sm mx-1">
                                <i class="fas fa-pen"></i></a> 
                              
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table> <br>

       

            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\copia\resources\views/products/index.blade.php ENDPATH**/ ?>