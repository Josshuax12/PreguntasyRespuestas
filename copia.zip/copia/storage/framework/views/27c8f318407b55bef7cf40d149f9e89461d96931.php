

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-5xl text-center pt-24">Bienvenido a tu perfil de BoxBook</h1>
    <div class="flex justify-center flex-wrap mt-16 mx-12">
        <?php $__currentLoopData = $imagesU; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-4/12 p-4 hover:bg-blue-500 hover:text-white">
                <p>

                    <ul class="text-white text-center">
                        <li><i class="fa-solid fa-book" >: <?php echo e($row->titulo); ?> </i></li>
                        <li><i class="fa-solid fa-user" >: <?php echo e($row->autor); ?></i></li>
                        <li><i class="fa-solid fa-newspaper">: <?php echo e($row->editorial); ?></i></li>
                        <li><i class="fa-solid fa-list">: <?php echo e($row->categoria); ?></i></li>
                        <li><i class="fa-solid fa-list">: <?php echo e($row->estatus); ?></i></li>
                        <li><i class="fa-solid fa-list">: <?php echo e($row->reseña); ?></i></li>
                        <li><i class="fa-solid fa-list">: <?php echo e($row->avance); ?></i></li>
                        <li><i class="fa-solid fa-list">: <?php echo e($row->comAvance); ?></i></li>
                        <li><i class="fa-solid fa-list">: <?php echo e($row->metaAnual); ?></i></li>
                    </ul>
                    
                </p><br>

                <img class="w-full h-4/5" src="ImgU/<?php echo e($row->imageU); ?>" alt="imageU">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Biblioteca\resources\views//admin/HomeU.blade.php ENDPATH**/ ?>