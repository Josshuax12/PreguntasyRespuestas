@extends('layouts.app')

@section('title', 'Home')

@section('content')

    <nav class="h-16 flex justify-end py-4 px-16">
     

        <a href="{{ route('products.create') }}" class="text-white rounded px-4 pt-1 h-10 bg-yellow-500 font-semibold mx-2 hover:bg-yellow-600">Preguntar y Respuesta</a>
    </nav>
    
    <div align="center"><img src="R.png"></div>
    
    <h1 class="text-5xl text-center pt-24">Bienvenido a la pagina Preguntados</h1><br><br>


        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
          <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                
                <table class="table-fixed w-full">
                    <thead>
                        <tr class="bg-red-500 text-white">
                  
        
<th class="w-1/16 py-4 ...">Nombre</th>
<th class="w-1/16 py-4 ...">Edad</th>
<th class="w-1/16 py-4 ...">Situacion </th>
<th class="w-1/16 py-4 ...">Descripcion</th>
<th class="w-1/16 py-4 ...">Correo</th>
<th class="w-1/16 py-4 ...">Usuario o invitado</th>
                  
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($products as $products)
                        <tr>
                            <td class="py-3 px-6"><div> {{$products->titulo}}</div></td>
                            <td class="p-3 txt-center"> {{$products->autor}}  </td>
                            <td class="p-3 text-center">{{$products->editorial}}</td>
                            <td class="p-3 text-center">{{$products->lpublicacion}}</td>
                            <td class="p-3 text-center">{{$products->apublicacion}}</td>
                            <td class="p-3 text-center">{{$products->categoria}}</td>
                   
                            <td class="p-3 flex justify-center">
                                <form href="#">
                               
                                    <form action="{{ route('index.destroy',$products->titulo)}}" method="POST" class="mx-auto">
                                    @csrf
                                    @method('delete')  
                  <button class="bg-red-500 text-white px-3 py-1 rounded-sm">
                  <i class="fas fa-trash"></i></button>
                </form>
             

                                <form>
                                <a href="" class="bg-green-500 text-white px-3 py-1 rounded-sm mx-1">
                                <i class="fas fa-pen"></i></a> 
                              
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table> <br>

       

            </div>
        </div>

@endsection